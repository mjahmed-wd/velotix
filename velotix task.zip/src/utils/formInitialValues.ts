export const donationFormInitValue = {
  creditCardNo: "",
  expirationDateMonth: "",
  expirationDateYear: "",
  cvvCode: "",
  firstName: "",
  lastName: "",
  donationAmount: "",
};
