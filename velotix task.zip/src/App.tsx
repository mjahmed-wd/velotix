import Payment from './modules/Payment';

import "./App.css"

function App() {
  return (
    <div className='d-flex justify-content-center align-items-center'>
      <Payment />
    </div>
  );
}

export default App;
